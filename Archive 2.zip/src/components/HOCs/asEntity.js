import React from "react";
import {connect} from 'react-redux';
import get from 'lodash/get';
import EntityActions from '../Redux/Actions/Entity'
import mapStateToProps from "react-redux/lib/connect/mapStateToProps";

export default function (configure = {}) {
const {storeKey,keepEntity} = configure;
    return Component => {
    class Entity extends React.Component{
        constructor(props) {
            super(props);
            this.component = React.createRef();
        }

        componentDidMount() {
            this.props.register(storeKey);
        }
        get store(){
            const state = get(this,`props.entity.byKey.${storeKey}`,{});
            const actions = {
                get:this.get,
                post:this.post
            };
            return {
                ...state,
                ...actions
            };
        };
        get = (...rest) => {
            this.props.get(storeKey,...rest)
        };
        post = (...rest) =>{
            this.props.post(storeKey,...rest)
        };
        resetProps = (...rest) => {
            this.props.resetProps(storeKey,...rest)
        };
        componentDidUpdate(prevProps, prevState, snapshot) {
            const {
                didGet,
                getData,
                didPost,
                postData,
                didPut,
                putData,
                didDelete,
                deleteData,
                catchPost,
            } = this.store;
            if(didGet){
                this.resetProps(['didGet','postData']);
                this.component.current.entityDidGet(getData);
            }
        }
        render() {
            return <Component ref = {this.component} $store={this.store}/>
        }
        componentWillUnmount() {
            if(!keepEntity){
                this.props.removeEntity(storeKey)
            }
}
    }
    const mapStateToProps = store => ({
            entity:store.entity
        });
    const mapDispatchToProps = dispatch => ({
            post:(...rest) => dispatch(EntityActions.post(...rest)),
            get: (...rest) => dispatch(EntityActions.get(...rest)),
            register:(...rest) => dispatch(EntityActions.register(...rest)),
            removeEntity:(...rest) => dispatch(EntityActions.removeEntity(...rest))
        });

        return connect(mapStateToProps,mapDispatchToProps)(Entity);
    };


};