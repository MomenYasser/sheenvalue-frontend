import {put , delay} from 'redux-saga/effects';
import EntityAction from '../Actions/Entity'
export default {
    *get({key , data}){},
    *post({key ,data}){

    }
}