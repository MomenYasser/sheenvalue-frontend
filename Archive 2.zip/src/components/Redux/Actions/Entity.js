import {createActions ,createReducer} from 'reduxsauce'
import Immutable from 'seamless-immutable';
import reduce from 'lodash/reduce'

const {Types , Creators}  = createActions({
    register:['key'],
    get:['key','data'],
    post:['key','data'],
    put:['key','data'],
    delete:['key','data'],

    didGet:['key','data'],
    didPost:['key','data'],
    didPut:['key','data'],
    didDelete:['key','data'],

    catchGet:['key','data'],
    catchPost:['key','data'],
    catchPut:['key','data'],
    catchDelete:['key','data'],

    resetProps:['key','props'],
    removeEntity:['key']
},{
    prefix:'Entity/'
});
export const EntityTypes = Types;
export default Creators
let ENTITY_INITIAL_STATE = Immutable({
 loading: false,
  errors: null ,
  didPost:false,
  didGet:false,
  didPut:false,
  didDelete:false,
  catchPost:false,
  catchGet:false,
  catchPut:false,
  catchDelete:false,
    getData: null,
    postData: null,
    putData: null,
    deleteData: null,
});

let INITIAL_STATE = Immutable({
    byKey:{}
});

/// REDUCDERS

export const get = (state, {key , data}) => {
    return state.merge({
        byKey:{
            ...state.byKey,
            [key]:{
                ...state.byKey[key],
                loading:true
            }
        }
    })
};

export const register = (state,{key , data}) => {
    return state.merge({
        byKey:{
            ...state.byKey,
            [key]: ENTITY_INITIAL_STATE
        }
    })
};
export const post = (state,{key , data}) =>{
    return state.merge({
        byKey:{
            ...state.byKey,
            [key]:{
                ...state.byKey[key],
                loading: true,

            }
        }
    })
};
export const removeEntity = (state,{key}) => {
    state.merge({
        byKey:{
            ...state.byKey,
            ...reduce(state.byKey,(result ,entity , name)=>{
                if(name !== key){
                    result[name] = entity
                }
                return result
            },{})
        }
    })
}
/// Hookup Actions To Types
export const reducer = createReducer(INITIAL_STATE , {
    [Types.GET]:get,
    [Types.REGISTER]:register,
    [Types.POST]:post,
    [Types.removeEntity]:removeEntity


});

