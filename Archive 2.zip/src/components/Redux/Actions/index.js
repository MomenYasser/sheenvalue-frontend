import {reducer as entity} from './Entity';
export default {
    entity,
}