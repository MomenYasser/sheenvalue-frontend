import React, { Component } from 'react'
import Input from './input'
import './form.css'
class Form extends Component{

    initForm = (form) => {
        this.setState(form)
    }
    validateForm = () =>{
        const data = {}
        for (const key in this.state.data) {
            if (this.state.data.hasOwnProperty(key)) {
                let validators = [] 
                
                this.state.data[key].validators.forEach((validator) => {
                    validators.push( validator(this.state.data[key].value))
                });
                console.log(validators.find(item => item === false))
                data[key] = {
                    ...this.state.data[key],
                    isValid:!!validators.find(item => item === false)
                }
            }
            
        }
        this.setState( {data})
        console.log(data)
    }
    checkAll = () =>{
        for (const key in this.state.data) {
            if (this.state.data.hasOwnProperty(key)) {
               if(!this.state.data[key].isValid){
                   console.log('Not PASSED')
               }
                    
        }
    }
}
    

    
    isRequired = (value) => {
        if(value === ''){
            alert('this Field is Required')
            return false
        }
        return true 
    }
     isEmail = (email) => {
        var filter = /^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
        if( String(email).search (filter) != -1 )
        return true
        alert('Email should be of pattern abc@example.xyz') ;
        return false
    }
    // handleChange = ({currentTarget:input},item) =>{
    //     let newItem = this.state.data
    //     newItem[item] = input.value
    //     this.setState({data:newItem})
    //     console.log(this.state.data)
    
    // }
    onChange = (key ,val)=>{
        this.setState({
          data:{ 
               ...this.state.data,
            [key] : {
                ...this.state.data[key],
                value:val
            }}
        })
    }
    // handleSubmit =()=>{
    //     console.log(this.state)
    //
    // }
   
   
    renderInput = (name,label,onchange,type="text")=>{
        return <div>
            <Input change={onchange}  name={name} type={type} label={label}/>
        </div>
    }
    renderButton=(title)=>{
       return <button  className="submitButton">{title}</button>
    }
}
export default Form