import React from 'react'
import Form from './form'
class SignIn extends Form{
  componentDidMount() {
      this.initForm({
        data:{
            email:{
                value:'',
                validators:[this.isEmail,this.isRequired],
                isValid:true
                },
            password:{
                value:'',
                validators:[this.isRequired],
                isValid:true
                }
        }
      })
  }

    validateEmpty = () =>{
        //   if (!this.state.validated && item === '')
        //     {
        //         this.setState({validated:true})
        //         console.log(this.state.validated)
        //         alert('Please Fill all Fields')
        //     }
        for(let key in this.state.data){
            if(this.state.data[key]==='')
            alert('Please Fill all Fields')
            break
        }
    }
    onSubmit=(e)=>{
        e.preventDefault()
        this.validateForm()
        this.checkAll()
       
               
    }
    
    render(){
        return <form  onSubmit={this.onSubmit}>
            {this.renderInput('username',"User Name",(e)=>this.onChange('email',e.target.value))}
            {this.renderInput('password','Password',(e)=>this.onChange('password',e.target.value),'passowrd')}
            {this.renderButton('Submit')}
        </form>
    }
}
export default SignIn