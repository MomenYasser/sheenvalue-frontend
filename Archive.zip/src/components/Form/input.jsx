import React from 'react'
import './input.css'
const input = ({name,label,change,...rest}) => (
    <div className="container">
        <label htmlFor={name} className="label">{label}</label>
        <input {...rest} name={name} id={name} onChange={change} className='myInput'/>
    </div>
)
export default input