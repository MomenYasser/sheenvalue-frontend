import React from 'react';
import logo from './logo.svg';
import './App.css';
import Form from './components/Form/form'
import SignIn from './components/Form/SignIn'
function App() {
  
  return (
    <SignIn />

  );
}

export default App;
